package main.dal.login;

import main.models.loginModel.entities.Login;

public class LoginDal {

	public boolean login(Login login) {
		return true;

	}

}

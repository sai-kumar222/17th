package main.models.storeModels.inputmodels;

public class ReturnId {

	private int returnId;

	public int getReturnId() {
		return returnId;
	}

	public void setReturnId(int returnId) {
		this.returnId = returnId;
	}
	
}

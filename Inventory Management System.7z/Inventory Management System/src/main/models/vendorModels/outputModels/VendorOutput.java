package main.models.vendorModels.outputModels;

public class VendorOutput {
	int vendorId;
	String vendorName;

	public VendorOutput() {

	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

}

package main.models.productModels.inputModels;

public class ProductsProductIdInputModel {

	private int productId;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public ProductsProductIdInputModel(int productId) {
		super();
		this.productId = productId;
	}

}
package main.models.grnModels.outputModels;

import java.util.List;

public class ImGrnOutputMapping {
	private List<ImGrnOutputModel> productsList;

}
